def LinearSearch(arr,target):
    for i in range(len(arr)):
        if arr[i]==target:
            return ("the element found at index ",i)
    return ("element not found")

arr=[]
n=int(input("Enter the size of the array: "))
for i in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)

target=int(input("Enter the searching Element: "))
print("input array: ",arr)
print(LinearSearch(arr,target))