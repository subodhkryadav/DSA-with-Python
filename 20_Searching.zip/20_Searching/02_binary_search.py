def BinarySearch(arr,target):
    low=0
    high=len(arr)-1
    while(low<=high):
        mid=(low+high)//2
        if arr[mid]==target:
            return "element found at index: ",mid
        elif (arr[mid]<target):
            low=mid+1
        else:
            high=mid-1
    return "the element not present in the array"

arr=[]
n=int(input("Enter the length of the array: "))
print("array input which is the sorted order:")
for i in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)
target=int(input("enter the searching element: "))
print(BinarySearch(arr,target))