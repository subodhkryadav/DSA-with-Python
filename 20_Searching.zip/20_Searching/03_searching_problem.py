def lowerBound(arr, x):
    for i in range(len(arr)):
        if arr[i] >= x:
            return f"The lower bound value is: {arr[i]} and its index is: {i}"
    return "No element greater than or equal to x found"

# Test cases
arr = [1, 2, 5, 8, 10]
x = 4
print(lowerBound(arr, x))  # Output: 5 at index 2

arr1 = [2, 3, 3, 3, 4, 6]
x1 = 3
print(lowerBound(arr1, x1))  # Output: 3 at index 1