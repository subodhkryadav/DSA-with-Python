# write a program to the user input array sort using the insertion sort
def Insertionsort(arr):
    for i in range(1,len(arr)):
        key=arr[i]
        j=i-1
        while(j>=0 and key<arr[j]):
            arr[j+1]=arr[j]
            j=j-1
        arr[j+1]=key

    return arr

arr=[]
n=int(input("Enter the number of the element contain in the array: "))
for i in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)

print("unsorted array: ",arr)
print("  sorted array: ",Insertionsort(arr))