# increasing order
def Selection_Sort(arr):
    n=len(arr)
    for i in range(n):
        max_index=i
        for j in range(1+i,n):
            if(arr[j]>arr[max_index]):
                max_index=j
        arr[i],arr[max_index]=arr[max_index],arr[i]

    return arr

#calling the method
arr=[]
n=int(input("enter the number of element present in the array: "))
for i in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)

print("Unsorted array: ",arr)
print("  sorted array: ",Selection_Sort(arr))