# increasing  order 
def Selection_sort(arr):
    n=len(arr)
    for i in range(n):
        min_index=i
        for j in range(i+1,n):
            if(arr[j]<arr[min_index]):
                min_index=j
        arr[i],arr[min_index]=arr[min_index],arr[i]

    return arr

#calling the method
arr=[]
n=int(input("enter the number of elemet of the array: "))
for i in range(n):
    element=int(input(f"enter the array {i+1 } element: "))
    arr.append(element)

print("Unsorted array: ",arr)
print('  Sorted array: ',Selection_sort(arr))
    