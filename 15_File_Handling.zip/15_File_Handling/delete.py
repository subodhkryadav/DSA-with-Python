import os
os.remove("path of the file which you want to delete")