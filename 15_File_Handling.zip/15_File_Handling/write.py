file=open("C:\\dsa with python\\15_File_Handling\\file2.txt",'w')
file.write("hello subodh ")
file.write("Jagannath university jaipur")
file.close()