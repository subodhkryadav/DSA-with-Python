file=open("C:\\dsa with python\\15_File_Handling\\file.txt",'r')

#open the file using the loop
"""
for line in file:
    print(line)

# after close the file
file.close()  
"""


#using the direct
"""
print(file.read())
"""


# using the with
"""
with open("C:\\dsa with python\\15_File_Handling\\file.txt",'r') as file:
    data =file.read()
    print(data)
"""

#using the with open the some part of the file
with open("C:\\dsa with python\\15_File_Handling\\file.txt",'r') as file:
    data =file.read(10)    #read the limited part of the file in this code read the only 10 char
    print(data)

file.close()