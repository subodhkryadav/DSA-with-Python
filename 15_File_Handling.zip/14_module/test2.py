from My_module import sum,mult   #when call the all method then "from my_module import *"
print("sum is: ",sum(3,5))
print("multiplication is: ",mult(3,5))