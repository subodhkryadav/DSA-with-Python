def LowerBond(arr, target):
    n = len(arr)
    if n == 0:
        return 'The array does not contain any type of the number'

    arr.sort()  # Ensure array is sorted

    if target > arr[-1]:
        return 'The target element is bigger than the array biggest element'

    for i in range(n):
        if arr[i] == target:
            return i
        if i < n - 1 and arr[i] < target < arr[i + 1]:
            return i + 1

    # If target is smaller than all elements
    if target < arr[0]:
        return 0

    # If target is equal to last element
    if arr[-1] == target:
        return n - 1

    return 'Target not found, but within range'

arr = []
n = int(input("Enter the size of the array: "))
for i in range(n):
    element = int(input(f"Enter the array {i+1} element: "))
    arr.append(element)

target = int(input("Enter the target element: "))
print("Array input:", arr)
print("Lower bound index:", LowerBond(arr, target))