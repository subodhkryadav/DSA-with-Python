def Banry_Lowar_bnd(arr,x):
    low=0
    high=len(arr)-1
    ans=len(arr)
    while(low<=high):
        mid=(low+high)//2
        if arr[mid]>=x:
            ans=mid
            high=mid-1
        else:
            low=mid+1
    return ans

arr=[]
n=int(input("Enter the size of the array: "))
print("Enter the sorted element: ")
for i  in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)
target=int(input("enter the target element: "))
print("array input: ",arr) 
print("lower bond index is: ",Banry_Lowar_bnd(arr,target))