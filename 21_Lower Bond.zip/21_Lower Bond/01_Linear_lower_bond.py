def Linear_lower_bond(arr,x):
    n=len(arr)
    for i in range(n):
        if arr[i]>=x:
            return i
    return i+1

arr=[]
n=int(input("Enter the size of the array: "))
for i  in range(n):
    element=int(input(f"Enter the array {i+1} element: "))
    arr.append(element)
target=int(input("enter the target element: "))
print("array input: ",arr) 
print("lower bond index is: ",Linear_lower_bond(arr,target))