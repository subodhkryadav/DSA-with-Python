# Q.   sort a string in decreasing order of values associated after removal of values smaller than x

def sortlist(str,x):
    #create the list
    my_list=str.split()
    n=len(my_list)
    # remove the pair who value is less than the given number
    for i in range(n-1,0,-2):
        if int(my_list[i]) < x:
            del (my_list[i-1: i+1])
    
    n=len(my_list)
    #sort the entire list(rest element)
    for i in range(1,n,2):
        for j in range(1,n-1,2):
            if(my_list[j]<my_list[j+2]) or (my_list[j-1]<my_list[j+1]) and (my_list[j]==my_list[j+2]):
                my_list[j],my_list[j+2]=my_list[j+2],my_list[j]
                my_list[j-1],my_list[j+1]=my_list[j+1],my_list[j-1]

    return " ".join(my_list)


#call the method
str="subodh 43 vikash 79 mohan 83 nikhil 79 shiwani 43"
print(sortlist(str,50))
