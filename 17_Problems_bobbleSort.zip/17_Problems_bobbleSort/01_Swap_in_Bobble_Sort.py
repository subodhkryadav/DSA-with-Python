# How much maximum swap are needed to sort array of length 6

def BobbleSort(arr):
    n=len(arr)
    count=0
    for i in range(n-1):
        is_sorted=True
        for j in range(n-1-i):
            if arr[j]>arr[j+1]:
                count=count+1                
                is_sorted=False
                arr[j],arr[j+1]=arr[j+1],arr[j]
        if is_sorted:
            break       
    print("the count is: ",count)
    return arr


arr=[]
n=int(input("enter the number of element in the arr: "))
for i in range(n):
    element=int(input(f"enter the array {i+1}st element: "))
    arr.append(element)
print("unsorted array: ",arr)

print("  sorted array: ",BobbleSort(arr))