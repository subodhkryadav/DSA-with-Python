# Q.  push zeros to the end while manintaining the relative order of the other element

def push_zeros_to_end(arr):
    count=0
    n=len(arr)
    temp=[0]*n

    for i in range(n):
        if (arr[i]!=0):
            temp[count]=arr[i]
            count+=1
    while(count<n):
        temp[count]=0
        count=count+1

    for i in range(n):
        arr[i]=temp[i]


    return arr

# call the method
arr=[1,2,0,4,3,0,5,0]
print(push_zeros_to_end(arr))