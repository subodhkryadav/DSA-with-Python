def PeekfndBinry(arr):
    n=len(arr)
    if n==0:
        return "the array is empty"
    low=0
    high=n-1
    while(low<=high):
        mid=(low+high)//2
        if arr[mid-1]<arr[mid]>arr[mid+1]:
            return mid
        elif arr[mid]<arr[mid+1]:
            low=mid+1
        else:
            high=mid-1
    return mid

arr=[]
n=int(input("Enter the size of the array: "))
for i in range(n):
    element=int(input(f"enter the array {i+1} element: "))
    arr.append(element)
print("input array: ",arr)
print("index of the peek element: ",PeekfndBinry(arr))