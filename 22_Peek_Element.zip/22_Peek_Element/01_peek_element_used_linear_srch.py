def PeekFind(arr):
    n=len(arr)
    if n==0:
        return 'there are no element contain the array'
    if arr[0]>arr[1]:
        return 0
    
    if arr[n-1]>arr[n-2]:
        return n-1
    
    for i in range(n):
        if (arr[i]>arr[i+1]) & (arr[i]>arr[i-1]):
            return i
    
arr=[]
n=int(input("enter the size of the array: "))
for i in range(n):
    element=int(input(f"enter the array {i+1} element: "))
    arr.append(element)
print("input array: ",arr)
print("index of peek element is: ",PeekFind(arr))
