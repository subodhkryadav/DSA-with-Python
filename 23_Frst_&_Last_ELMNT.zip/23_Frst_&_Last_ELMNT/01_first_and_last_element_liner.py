def FirstLast_index(arr,x):
    n=len(arr)
    first=-1
    last=-1

    for i in range(n):
        if (arr[i]!=x):
            continue
        if first==-1:
            first=i
        last=i

    return [first,last]

arr=[]
n=int(input("Enter the size of the array: "))
for i in range(n):
    element=int(input(f"enter the array {i+1} element: "))
    arr.append(element)
print("array input: ",arr)
x=int(input("enter the seaching element: "))
print("[ first,last ] index:-",FirstLast_index(arr,x))