def first(arr, x):
    low, high = 0, len(arr) - 1
    res = -1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] > x:
            high = mid - 1
        elif arr[mid] < x:
            low = mid + 1
        else:
            res = mid
            high = mid - 1  # keep searching left
    return res

def last(arr, x):
    low, high = 0, len(arr) - 1
    res = -1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] > x:
            high = mid - 1
        elif arr[mid] < x:
            low = mid + 1
        else:
            res = mid
            low = mid + 1  # keep searching right
    return res


# ---------- Main Program ----------
n = int(input("Enter the size of the array: "))

# Take all elements in ONE line
arr = list(map(int, input(f"Enter {n} elements (space-separated): ").split()))

x = int(input("Enter the searching element: "))

arr.sort()
print("Sorted array is:", arr)

f = first(arr, x)
l = last(arr, x)

if f == -1:
    print("Element not found in array")
else:
    print("[first,last] index:-", [f, l])
