import My_module 
print(My_module.cube(3))
