def cube(num):
    return num*num*num

def sum(a,b):
    return a+b

def mult(a,b):
    return a*b

def sqare(num):
    return num*num